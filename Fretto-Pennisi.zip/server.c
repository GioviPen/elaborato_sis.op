#include "common.h"

// Definizione dei codici di priorit�
typedef enum {
	CODICE_ROSSO = 1,
	CODICE_ARANCIONE,
	CODICE_AZZURRO,
	CODICE_VERDE,
	CODICE_BIANCO = 5
} CodicePriorita;

// Struttura del paziente da anagrafica
typedef struct {
	char nome[MAX_LEN];
	char cognome[MAX_LEN];
	char provincia[5];
	int eta;
	CodicePriorita priorita;
} Paziente;

// Struttura della coda
typedef struct {
	Paziente* elementi;
	int capacita;
	int testa;
	int coda;
	int numeroElementi;
	sem_t semaforo;
} CodaPazienti;

// Struttura contenente cinque code, una per ogni priorit�
typedef struct {
	CodaPazienti code[5];
} CodePriorita;

typedef struct {
	FILE* fileAnagrafica;
	CodePriorita* code;
	Paziente(*elencoPazienti)[5];
	int* numPazienti;
	pthread_cond_t condizioneTerminazione;
	int contatoreIterazioni;
} ThreadCaricaCasualeArgs;

// Struttura per rappresentare una richiesta del client
typedef struct {
	int client_id;
	int tipoRichiesta;
	Paziente paziente;
} RichiestaClient;

//semafori
sem_t* mutex;
sem_t* empty;
sem_t* full;

// Dichiarazione del mutex orologio
pthread_mutex_t muto = PTHREAD_MUTEX_INITIALIZER;

int server_running = 1;  // Flag per indicare se il server � in esecuzione
// Posizione iniziale del cursore (per goto) e parametri orologio
int currentX = 1, currentY = 1;
int giorno = 1;
int ore = 0, minuti = 0;

// Variabili globali
CodePriorita* shared_memall;
int shmid;

// Prototipi delle funzioni
void inizializzaCoda(CodaPazienti* coda, int capacita);
void inizializzaCodePriorita(CodePriorita* code, int capacita);
void inserisciInCoda(CodaPazienti* coda, Paziente* paziente);
void inserisciInCodaPriorita(CodePriorita* code, Paziente* paziente);
Paziente estraiDaCoda(CodaPazienti* coda);
Paziente estraiDaCodaPriorita(CodePriorita* code, CodicePriorita priorita);
void rimuoviPaziente(CodePriorita* code, Paziente elencoPazienti[][5], int* numPazienti, Paziente pazienteRim);
bool confrontaPazienti(const Paziente* p1, const Paziente* p2);
int generaNumeroCasuale(int minimo, int massimo);
void inserisciPaziente(CodaPazienti* coda, Paziente elencoPazienti[][5], int* numPazienti, Paziente* paziente);
void inserisciPazientePriorita(CodePriorita* code, Paziente elencoPazienti[][5], int* numPazienti, Paziente* paziente);
Paziente caricaCasuale(FILE* file, CodePriorita* code, Paziente elencoPazienti[][5], int* numPazienti);
void* threadCaricaCasuale(void* args);
CodicePriorita assegnaPrioritaCasuale();

void gestisciConnessioneClient(int client_socket, CodePriorita* code, Paziente elencoPazienti[][5], int* numPazienti);
void gestisciServer(CodePriorita* code, Paziente elencoPazienti[][5], int* numPazienti);

int create_shared_memory(size_t size);
void* attach_shared_memory(int shmid);
void initialize_semaphores();
void distruggiSemafori(CodePriorita* codePriorita);
void liberaMemoriaCondivisa();

void tempoScorre();
void* orologio(void* args);
void gotoxy(int x, int y);

int main() {
	// Inizializzazione del generatore di numeri casuali
	srand(time(NULL));
	system("clear");
	// Creazione e attach della memoria condivisa
	shmid = create_shared_memory(sizeof(CodePriorita));
	shared_memall = (CodePriorita*)attach_shared_memory(shmid);

	initialize_semaphores(); // Inizializzazione dei semafori

	FILE* fileAnagrafica = NULL;
	if ((fileAnagrafica = fopen("anagrafica.txt", "r")) == NULL) {
		gotoxy(55, 7);
		printf(ROSSO "Errore nell'apertura del file anagrafica.txt\n" RESET);
		fflush(stdout);
		return -1;
	}

	pthread_t orologio_tid; // Crea il thread per l'orologio
	if (pthread_create(&orologio_tid, NULL, orologio, NULL) != 0) {
		perror("pthread_create orologio");
		exit(EXIT_FAILURE);
	}
	pthread_t caricaCasuale_thread;

	CodePriorita codePriorita;// Creazione delle code di priorit�
	inizializzaCodePriorita(&codePriorita, BUFFER_SIZE);

	// Lettura dei pazienti dal file e assegnazione priorita
	int numPazienti = 0; //totale

	// Array per tenere traccia dei pazienti per ogni codice di priorit�
	Paziente elencoPazienti[NUM_NOMI][5] = { 0 }; // 5 � il numero di codici di priorit�

	//caricaCasuale(fileAnagrafica, &codePriorita, elencoPazienti, &numPazienti);
	//caricaTuttoFile(fileAnagrafica, &codePriorita, elencoPazienti, &numPazienti);
	// Dichiarazione e allocazione dinamica della struttura
	ThreadCaricaCasualeArgs* threadArgs = (ThreadCaricaCasualeArgs*)malloc(sizeof(ThreadCaricaCasualeArgs));
	if (threadArgs == NULL) {
		perror("malloc");
		exit(EXIT_FAILURE);
	}
	threadArgs->fileAnagrafica = fileAnagrafica;
	threadArgs->code = &codePriorita;
	threadArgs->elencoPazienti = elencoPazienti;
	threadArgs->numPazienti = &numPazienti;
	threadArgs->contatoreIterazioni = 0;

	pthread_mutex_init(&muto, NULL);
	pthread_cond_init(&threadArgs->condizioneTerminazione, NULL);

	// Creazione del thread e passaggio del puntatore alla struttura come argomento
	if (pthread_create(&caricaCasuale_thread, NULL, threadCaricaCasuale, (void*)threadArgs) != 0) {
		perror("pthread_create");
		exit(EXIT_FAILURE);
	}

	//salva le cinque code nella memoria condivisa
	for (int i = 0; i < 5; i++) {
		/*memcpy(&(shared_memall->code[i]), &(codePriorita.code[i]), sizeof(CodaPazienti));*/
		shared_memall->code[i] = codePriorita.code[i];
	}

	gestisciServer(&codePriorita, elencoPazienti, &numPazienti); // Avvio del server
	// Il resto del codice non sar� eseguito finch� il server � in esecuzione

	pthread_mutex_lock(&muto);
	pthread_cond_wait(&threadArgs->condizioneTerminazione, &muto);
	pthread_mutex_unlock(&muto);
	pthread_cond_destroy(&threadArgs->condizioneTerminazione);

	// Chiusura del thread dell'orologio
	if (pthread_join(orologio_tid, NULL) != 0) {
		perror("pthread_join");
		exit(EXIT_FAILURE);
	}
	if (pthread_cancel(orologio_tid) != 0) {
		perror("pthread_cancel");
		exit(EXIT_FAILURE);
	}
	// Attende la terminazione del thread della carica casuale e chiude
	if (pthread_join(caricaCasuale_thread, NULL) != 0) {
		perror("pthread_join");
		exit(EXIT_FAILURE);
	}
	if (pthread_cancel(caricaCasuale_thread) != 0) {
		perror("pthread_cancel");
		exit(EXIT_FAILURE);
	}
	fclose(fileAnagrafica);
	distruggiSemafori(&codePriorita);  // Liberazione delle risorse del semaforo
	pthread_mutex_destroy(&muto); // Distrugge il mutex prima di uscire
	liberaMemoriaCondivisa(); // Libera la memoria condivisa
	free(threadArgs); // Libera la memoria allocata per la struttura
	for (int i = 0; i < 5; i++) { //libera la memoria allocata per le code
		free(codePriorita.code[i].elementi);
	}
	printf("\nProgramma terminato con successo.\n");
	return 0;
}

// Funzione per inizializzare la coda
void inizializzaCoda(CodaPazienti* coda, int capacita) {
	coda->elementi = (Paziente*)malloc(capacita * sizeof(Paziente));
	if (coda->elementi == NULL) {
		perror("malloc");
		exit(EXIT_FAILURE);
	}
	coda->capacita = capacita;
	coda->testa = 0;
	coda->coda = -1;
	coda->numeroElementi = 0;
	if (sem_init(&coda->semaforo, 0, 1) == -1) {// Inizializzazione del semaforo per l'accesso alla coda
		perror("sem_init");
		exit(EXIT_FAILURE);
	}
}

// Funzione per inizializzare le 5 code di priorit�
void inizializzaCodePriorita(CodePriorita* code, int capacita) {
	for (int i = 0; i < 5; i++) {
		inizializzaCoda(&(code->code[i]), capacita);
	}
}

// Funzione per inserire un paziente nella coda
void inserisciInCoda(CodaPazienti* coda, Paziente* paziente) {
	sem_wait(&coda->semaforo);  // Wait sul semaforo, garantisce mutua esclusione
	if (coda->numeroElementi == coda->capacita) {
		gotoxy(55, 7);
		printf(GIALLO "La coda %d e' piena, aumento la capacita'\n" RESET, paziente->priorita);
		fflush(stdout);
		sleep(3);
		gotoxy(55, 7);
		printf("                                                     ");
		coda->capacita *= 2;
		coda->elementi = (Paziente*)realloc(coda->elementi, coda->capacita * sizeof(Paziente));
	}
	coda->coda = (coda->coda + 1) % coda->capacita;
	coda->elementi[coda->coda] = *paziente;
	coda->numeroElementi++;
	sem_post(&coda->semaforo);  // Signal sul semaforo (rilascio)
}

// Funzione per inserire un paziente nella coda corrispondente alla sua priorit�
void inserisciInCodaPriorita(CodePriorita* code, Paziente* paziente) {
	inserisciInCoda(&(code->code[paziente->priorita - 1]), paziente);
}

// Funzione per estrarre un paziente dalla coda generale
Paziente estraiDaCoda(CodaPazienti* coda) {
	Paziente pazienteEstratto;
	sem_wait(&coda->semaforo);  // Wait sul semaforo
	if (coda->numeroElementi == 0) {
		gotoxy(55, 7);
		printf("La coda � vuota, impossibile estrarre elementi.\n");
	}
	else {
		pazienteEstratto = coda->elementi[coda->testa];
		coda->testa = (coda->testa + 1) % coda->capacita;
		coda->numeroElementi--;
	}
	sem_post(&coda->semaforo);  // Signal sul semaforo
	return pazienteEstratto;
}

// Funzione per estrarre un paziente dalla coda corrispondente alla sua priorit�
Paziente estraiDaCodaPriorita(CodePriorita* code, CodicePriorita priorita) {
	return estraiDaCoda(&(code->code[priorita - 1]));
}

void rimuoviPaziente(CodePriorita* code, Paziente elencoPazienti[][5], int* numPazienti, Paziente pazienteRim) {
	CodicePriorita priorita = pazienteRim.priorita;

	if (priorita < CODICE_ROSSO || priorita > CODICE_BIANCO) {
		gotoxy(55, 7);
		printf(ROSSO "Errore: Codice di priorita' %d non valido." RESET, priorita);
		fflush(stdout);
		sleep(3);
		gotoxy(55, 7);
		printf("                                                        ");
		return;
	}
	if (code->code[priorita - 1].numeroElementi == 0) { //se la coda � vuota
		gotoxy(55, 7);
		printf(ROSSO "Errore: Nessun paziente trovato nella coda di priorita' %d." RESET, priorita);
		fflush(stdout);
		sleep(3);
		gotoxy(55, 7);
		printf("                                                                   ");
		return;
	}

	Paziente pazienteEstratto = estraiDaCodaPriorita(code, priorita); // Rimuovi il paziente dalla coda corrispondente alla priorita

	if (memcmp(&pazienteEstratto, &pazienteRim, sizeof(Paziente)) == 0) {
		gotoxy(55, 5);
		printf("                                                     ");
		printf("Paziente rimosso con successo.");
	} //utilizzare confrontaPazienti 
	else {
		gotoxy(55, 5);
		printf("                                                     ");
		printf("Paziente non corrispondente.  ");
	}
}

bool confrontaPazienti(const Paziente* p1, const Paziente* p2) {
	return strcmp(p1->nome, p2->nome) == 0 &&
		strcmp(p1->cognome, p2->cognome) == 0 &&
		strcmp(p1->provincia, p2->provincia) == 0 &&
		p1->eta == p2->eta &&
		p1->priorita == p2->priorita;
}

// Funzione per generare un numero casuale compreso tra minimo e massimo
int generaNumeroCasuale(int minimo, int massimo) {
	return rand() % (massimo - minimo + 1) + minimo;
}

// Funzione per inserire il paziente nella coda e nell'elenco
void inserisciPaziente(CodaPazienti* coda, Paziente elencoPazienti[][5], int* numPazienti, Paziente* paziente) {
	paziente->priorita = assegnaPrioritaCasuale(); // Assegnazione casuale del codice di priorit�
	elencoPazienti[*numPazienti][paziente->priorita] = *paziente; // Aggiungo il paziente all'elenco corrispondente al suo codice di priorit�
	inserisciInCoda(coda, paziente); // Inserimento del paziente nella coda
	(*numPazienti)++;
	printf("Paziente inserito nella coda.\n");
}

// Funzione per inserire il paziente nella coda e nell'elenco
void inserisciPazientePriorita(CodePriorita* code, Paziente elencoPazienti[][5], int* numPazienti, Paziente* paziente) {
	paziente->priorita = assegnaPrioritaCasuale(); // Assegnazione casuale del codice di priorit�
	elencoPazienti[*numPazienti][paziente->priorita - 1] = *paziente; // Aggiungo il paziente all'elenco corrispondente al suo codice di priorit�
	inserisciInCodaPriorita(code, paziente); // Inserimento del paziente nella coda
	(*numPazienti)++;
}

// Caricamento casuale di un solo paziente dal file
Paziente caricaCasuale(FILE* file, CodePriorita* code, Paziente elencoPazienti[][5], int* numPazienti) {
	Paziente paziente;
	int nRand = rand() % NUM_NOMI;
	rewind(file); // Riavvolgi il file all'inizio
	for (int riga = 0; riga < nRand; riga++) {
		char buffer[MAX_LEN * 4];
		if (fgets(buffer, sizeof(buffer), file) == NULL) {
			gotoxy(55, 7);
			printf(ROSSO "Errore durante la lettura del file alla riga %d\n" RESET, nRand);
			fflush(stdout);
			exit(EXIT_FAILURE);
		}
	}
	if (fscanf(file, "%s %s %s %d", paziente.nome, paziente.cognome, paziente.provincia, &paziente.eta) == 4) {
		inserisciPazientePriorita(code, elencoPazienti, numPazienti, &paziente);
	}
	else { // Se non riesce a leggere correttamente i dati
		gotoxy(55, 7);
		printf(ROSSO "Errore durante la lettura del paziente dalla riga %d\n" RESET, nRand);
		fflush(stdout);
		exit(EXIT_FAILURE);
	}
	return paziente;
}

void* threadCaricaCasuale(void* args) {
	ThreadCaricaCasualeArgs* threadArgs = (ThreadCaricaCasualeArgs*)args;
	int j = 0, q = 0;
	while (1) {
		Paziente ultimoPaziente = caricaCasuale(threadArgs->fileAnagrafica, threadArgs->code, threadArgs->elencoPazienti, threadArgs->numPazienti);
		pthread_mutex_lock(&muto);
		memcpy(shared_memall, &threadArgs->code->code, sizeof(CodePriorita));
		if (j == 10) { // Se la console � piena 
			for (int h = 0; h < 10; h++) {
				gotoxy(1, 3 + h);
				printf("                                                ");
			} // cancella 10 righe
			j = 0;
		}
		gotoxy(1, 3 + j);
		printf("Paziente %d, %s %s in arrivo.\n\n\n", q + 1, ultimoPaziente.nome, ultimoPaziente.cognome);
		q++;
		j++;
		pthread_mutex_unlock(&muto);
		fflush(stdout);
		sleep(1 + rand() % 5); //simula il tempo che passa casuale tra l'arrivo di due pazienti

		// Incrementa il contatore delle iterazioni
		threadArgs->contatoreIterazioni++;

		// Controlla se � il momento di terminare
		if (threadArgs->contatoreIterazioni >= 100) {
			// Notifica al thread principale che � il momento di terminare
			pthread_cond_signal(&threadArgs->condizioneTerminazione); // variabile di condizione
			break;
		}
	}
	pthread_exit(NULL);
}

// Funzione per l'assegnazione casuale della priorita
CodicePriorita assegnaPrioritaCasuale() {
	return (CodicePriorita)generaNumeroCasuale(CODICE_ROSSO, CODICE_BIANCO);
}

// Funzione per gestire la connessione del client al server
void gestisciConnessioneClient(int client_socket, CodePriorita* code, Paziente elencoPazienti[][5], int* numPazienti) {
	RichiestaClient richiesta;

	if (recv(client_socket, &richiesta, sizeof(RichiestaClient), 0) == -1) {// Ricevi la richiesta del client
		gotoxy(55, 7);
		perror(ROSSO "Errore nella ricezione della richiesta del client" RESET);
		fflush(stdout);
		close(client_socket);
		exit(EXIT_FAILURE);
	}
	gotoxy(55, 5);
	//printf("Server %d: Richiesta %d ricevuta dal client %d\n", getpid(), richiesta.tipoRichiesta, richiesta.client_id);  //debug
	fflush(stdout);

	rimuoviPaziente(code, elencoPazienti, numPazienti, richiesta.paziente);
	gotoxy(55, 5);
	printf("Client %d: Paziente %s %s rimosso con successo\n", richiesta.client_id, richiesta.paziente.nome, richiesta.paziente.cognome);
	fflush(stdout);

	// Invia un messaggio di conferma al client
	if (send(client_socket, "OK", sizeof("OK"), 0) == -1) {
		gotoxy(55, 7);
		perror(ROSSO "Errore nell'invio della conferma al client" RESET);
		fflush(stdout);
		exit(EXIT_FAILURE);
	}
	gotoxy(55, 5);
	//printf("Server %d: Conferma inviata al client %d\n", getpid(), richiesta.client_id);
	fflush(stdout);
}

// Funzione per gestire il server
void gestisciServer(CodePriorita* code, Paziente elencoPazienti[][5], int* numPazienti) {
	int server_socket, client_socket;
	struct sockaddr_in server_address, client_address;
	socklen_t client_address_len = sizeof(client_address);
	time_t ticks; // Variabile per memorizzare il tempo
	pid_t child_pid[MAX_CONNECTIONS]; // Array per tenere traccia dei processi figli

	// Creazione del socket del server
	if ((server_socket = socket(AF_INET, SOCK_STREAM, 0)) == -1) {
		gotoxy(55, 7);
		perror(ROSSO "Errore nella creazione del socket del server" RESET);
		fflush(stdout);
		exit(EXIT_FAILURE);
	}

	// Inizializzazione della struttura dell'indirizzo del server
	memset(&server_address, 0, sizeof(server_address));
	server_address.sin_family = AF_INET;
	server_address.sin_addr.s_addr = inet_addr(SERVER_IP);/*INADDR_ANY*/
	server_address.sin_port = htons(SERVER_PORT);

	// Associazione del socket all'indirizzo del server
	if (bind(server_socket, (struct sockaddr*)&server_address, sizeof(server_address)) == -1) {
		gotoxy(55, 7);
		perror(ROSSO "Errore nell'associazione del socket all'indirizzo del server" RESET);
		fflush(stdout);
		exit(EXIT_FAILURE);
	}

	fflush(stdout);
	gotoxy(55, 3);
	printf("In attesa della connessione del client...\n");// Messaggio di attesa della connessione del client

	// Mettere in ascolto il socket del server per le connessioni in ingresso
	if (listen(server_socket, MAX_CONNECTIONS) == -1) {
		gotoxy(55, 7);
		perror(ROSSO "Errore listen!" RESET);
		fflush(stdout);
		exit(EXIT_FAILURE);
	}
	gotoxy(55, 4);
	printf("Server in ascolto %s:%d...\n", SERVER_IP, ntohs(server_address.sin_port)/*SERVER_PORT*/);
	fflush(stdout);

	{
		// Handle SIGCHLD signal for reaping zombie processes
		struct sigaction sa;
		sa.sa_handler = SIG_IGN; // Ignore the signal
		sigemptyset(&sa.sa_mask);
		sa.sa_flags = SA_RESTART;
		if (sigaction(SIGCHLD, &sa, NULL) == -1) {
			perror("Error setting up SIGCHLD handler");
			close(server_socket);
			exit(EXIT_FAILURE);
		}
	}

	int i = 0;
	int nc = 0;
	while (i <= MAX_CONNECTIONS) {// Ciclo infinito per gestire le connessioni dei client
		// Accetta la connessione del client
		if ((client_socket = accept(server_socket, (struct sockaddr*)&client_address, &client_address_len)) == -1) {
			gotoxy(55, 7);
			perror(ROSSO "Errore nella connessione del client" RESET);
			fflush(stdout);
			exit(EXIT_FAILURE);
		}

		gotoxy(55, 3);
		printf("Client connesso: %s                 \n", inet_ntoa(client_address.sin_addr));
		gotoxy(55, 4);
		printf("                                     ");
		fflush(stdout);
		if (i >= MAX_CONNECTIONS) {
			gotoxy(0, 18);
			printf(ROSSO "Attenzione: Numero massimo di connessioni raggiunto. Impossibile accettare nuove connessioni." RESET);
			close(client_socket);
			continue;
		}

		gotoxy(55, 8 + nc);
		printf("Connessione %d accettata dal client %s:%d\n", client_socket, inet_ntoa(client_address.sin_addr), ntohs(client_address.sin_port));
		fflush(stdout);
		
		child_pid[i] = fork();
		if (child_pid[i] == -1) {
			gotoxy(55, 7);
			perror(ROSSO "Errore nella creazione del processo figlio" RESET);
			fflush(stdout);
			exit(EXIT_FAILURE);
		}
		else if (child_pid[i] == 0) { // Processo figlio
			close(server_socket); // Il processo figlio chiude il socket del server (non ne ha bisogno)
			if (send(client_socket, &shmid, sizeof(int), 0) == -1) { // Invia al client la shmid
				perror("Errore invio shmid al client");
				exit(EXIT_FAILURE);
			}
			gestisciConnessioneClient(client_socket, code, elencoPazienti, numPazienti); // Gestisce la connessione del client con la funzione apposita
			//altro prima di chiudere inserire qui
			if (close(client_socket) == 0) { // Chiude il socket del client quando la gestione � completata
				gotoxy(55, 8);
				printf("Client %d disconnesso.                                       \n", client_socket);
				fflush(stdout);
			}
			exit(EXIT_SUCCESS); // Termina il processo figlio
		}
		nc++;
		i++;
	}
	// Chiude il socket del server
	close(client_socket); // Padre chiude il socket del client
	if (close(server_socket) == 0) {
		gotoxy(55, 8);
		printf("Server disconnesso.                                       \n");
		fflush(stdout);
	}
	// Termina tutti i processi figli
	for (int i = 0; i < MAX_CONNECTIONS; i++) {
		if (child_pid[i] != 0) {
			kill(child_pid[i], SIGTERM);
		}
	}
}

// Funzione per la creazione della memoria condivisa
int create_shared_memory(size_t size) {
	key_t chiave = ftok(".", 'K');
	if (chiave == -1) {
		perror("ftok");
		exit(EXIT_FAILURE);
	}
	int shmid = shmget(chiave/*IPC_PRIVATE*/, size, IPC_CREAT | 0666);
	if (shmid == -1) {
		perror("shmget");
		exit(EXIT_FAILURE);
	}
	return shmid;
}

// Funzione generica per l'attach della memoria condivisa
void* attach_shared_memory(int shmid) {
	void* memory = shmat(shmid, NULL, 0);
	if (memory == (void*)-1) {
		perror("shmat");
		exit(EXIT_FAILURE);
	}
	return memory;
}

// Funzione per l'inizializzazione dei semafori
void initialize_semaphores() {
	sem_unlink("/mutex");
	sem_unlink("/empty");
	sem_unlink("/full");

	mutex = sem_open("/mutex", O_CREAT | O_EXCL, 0666, 1);    // Mutex inizializzato a 1 (semaforo binario)
	empty = sem_open("/empty", O_CREAT | O_EXCL, 0666, BUFFER_SIZE);  // Numero massimo di slot vuoti
	full = sem_open("/full", O_CREAT | O_EXCL, 0666, 0);     // Nessun slot pieno all'inizio

	if (mutex == SEM_FAILED || empty == SEM_FAILED || full == SEM_FAILED) {
		perror("sem_open");
		exit(EXIT_FAILURE);
	}
}

// Funzione per liberare le risorse del semaforo
void distruggiSemafori(CodePriorita* codePriorita) {
	for (int i = 0; i < 5; i++) {
		sem_destroy(&(codePriorita->code[i].semaforo));// Funzione per distruggere i semafori di una struttura CodePriorita
	}
	sem_destroy(mutex);
	sem_destroy(empty);
	sem_destroy(full);
	sem_close(mutex);
	sem_close(empty);
	sem_close(full);
	sem_unlink("/mutex");
	sem_unlink("/empty");
	sem_unlink("/full");
}

void liberaMemoriaCondivisa() {
	// Chiusura della memoria condivisa
	if (shmdt(shared_memall) == -1) {
		perror("shmdt");
		exit(EXIT_FAILURE);
	}
	// Rimozione della memoria condivisa
	if (shmctl(shmid, IPC_RMID, NULL) == -1) {
		perror("shmctl");
		exit(EXIT_FAILURE);
	}
	free(shared_memall);
}

void tempoScorre() {
	// Incrementa i minuti e aggiorna ore e giorni quando necessario
	minuti++;
	if (minuti == 60) {
		minuti = 0;
		ore++;
		if (ore == 24) {
			ore = 0;
			giorno++;
		}
	}
}

void* orologio(void* args) {
	while (1) {
		pthread_mutex_lock(&muto); // Blocca l'accesso alla console
		tempoScorre(); // Incrementa il tempo con l'apposita funzione
		gotoxy(1, 1); // posiziona il cursore e stampa il tempo
		printf("========== Pazienti In Arrivo ========== Day: %d |PRONTO SOCCORSO| [%02d:%02d] === Exit:CTRL+C\n", giorno, ore, minuti);
		pthread_mutex_unlock(&muto); // Sblocca l'accesso alla console
		usleep(6944); // 10 SECONDI veri -> UN GIORNO virtuale
		if (giorno == 30) {
			gotoxy(0, 14);
			printf("\nE' trascorso un mese\n");
		}
	}
}

void gotoxy(int x, int y) {
	printf("\033[%d;%dH", y, x);
	fflush(stdout);
	currentX = x;
	currentY = y;
}